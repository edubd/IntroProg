# ex.7 - cap. 1: explicar o programa
print('Digite o valor da base:')
base = int(input())
print('Digite o valor da altura:')
altura = int(input())
area = (base * altura) / 2
print(area)

# esse programa recebe valores de base e altura como entrada
# e faz o calculo da área do triângulo
