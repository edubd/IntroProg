# ex.6 - cap. 2: lê número inteiro e exibe sucessor e antecessor
x = int(input('digite um número inteiro: '))

print('o sucessor é:', x + 1)
print('o antecessor é:', x - 1)
