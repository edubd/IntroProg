# ex.8 - cap. 1: lê 2 números inteiros e soma, subtrai, multiplica e divide
print('digite dois números inteiros: ');
a = int(input())
b = int(input())

print('soma = ', a + b)
print('subtração = ', a - b)
print('multiplicação = ', a * b)
print('divisão = ', a / b)
