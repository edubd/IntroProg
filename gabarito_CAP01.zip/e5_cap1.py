# ex.5 - cap. 1: imprime mensagem na tela
print('Preciso fazer todos os exercícios para aprender')